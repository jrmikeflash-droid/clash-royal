# Tower Battle Swift Prototype

This repo contains the source files for a simple Clash Royale–style prototype built in Swift using SpriteKit.

## Files
- `GameScene.swift` — main battle gameplay
- `GameViewController.swift` — loads the scene

## How to Use
1. Create a new **iOS SpriteKit Game** project in Xcode.
2. Replace the auto-generated GameScene.swift and GameViewController.swift with these.
3. Build & run.

Suitable for cloud builders like CodeMagic, GitHub Actions (macOS runners), or MacStadium.

